---
name: GridPulse Korea
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#584237'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#8c7164'
  outline-variant: '#e0c0b1'
  surface-tint: '#9d4300'
  primary: '#9d4300'
  on-primary: '#ffffff'
  primary-container: '#f97316'
  on-primary-container: '#582200'
  inverse-primary: '#ffb690'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006c49'
  on-tertiary: '#ffffff'
  tertiary-container: '#00b07a'
  on-tertiary-container: '#003b26'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbca'
  primary-fixed-dim: '#ffb690'
  on-primary-fixed: '#341100'
  on-primary-fixed-variant: '#783200'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  metric-val:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  metric-val-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  margin: 1.5rem
  gutter-desktop: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system is tailored for an intuitive, accessible Korean energy market dashboard (전력시장 대시보드 - 오늘의 전기 시세). Its primary mission is to translate complex power market metrics—such as System Marginal Price (SMP), peak load capacity, and renewable contribution percentages—into straightforward, welcoming financial telemetry for retail investors, clean energy consumers, and market newcomers.

The visual direction merges **Modern Functional Minimalism** with **Warm Utility**. Rather than presenting cold, intimidating industrial terminal aesthetics, the interface communicates optimism, transparency, and clarity. It evokes confidence through institutional precision (anchored in official KPX data standards) while maintaining an encouraging, accessible consumer-fintech sensibility.

Key aesthetic principles:
- **Luminous Legibility:** Pristine white surfaces combined with cool slate neutrals eliminate visual clutter and reduce cognitive friction.
- **Electric Vitality:** Radiant electric amber and warm solar orange accents punctuate vital trends, peak price spikes, and dynamic fluctuations without introducing alarming visual noise.
- **Editorial Data Hierarchy:** High-density pricing and numeric grids feature dedicated tabular typography paired with plain-language micro-summaries and contextual AI callouts.

## Colors

The palette balances energetic electrical warmth with structured institutional navy and slate neutrals.

- **Primary (`#F97316` / Energetic Amber-Orange):** Represents live electric power, active SMP pricing, current intraday intervals, and primary calls-to-action. Deep orange (`#EA580C`) serves as the hover/active state, while soft amber tint (`#FFEDD5`) anchors active badge backgrounds, warning highlights, and timeline scubbers.
- **Secondary (`#0F172A` / Midnight Slate):** Provides high-contrast anchor weights for key values, major headline indicators, and deep navigational surfaces.
- **Tertiary (`#10B981` / Emerald Green):** Communicates market stability, downward cost adjustments, positive grid reliability, and clean renewable generation metrics.
- **Neutral (`#64748B` / Slate Neutral):** Powers secondary annotations, chart axis lines, data-source metadata, and subtle border dividers (`#E2E8F0` on canvas `#F8FAFC`).

### Surface Distribution
- **Canvas Base:** `#F8FAFC` provides a soft backdrop that prevents eye strain during extended analytical review.
- **Card Containers:** `#FFFFFF` creates crisp figure-ground separation with 1px border strokes (`#E2E8F0`).
- **Semantic Badges:** Tinted pastels (Amber 50: `#FFF7ED`, Emerald 50: `#ECFDF5`, Slate 100: `#F1F5F9`) preserve visual hierarchy without aggressive saturation.

## Typography

The typographic hierarchy prioritizes rapid scanning of numerical data alongside Korean text legibility. 

- **Font Pairing:** `Plus Jakarta Sans` provides geometric modernity and crisp character heights for primary headline locks and large metric readouts. `Inter` serves as the neutral workhorse for Korean and English body copy, table figures, and contextual notes. When rendering in production, fallback to `Pretendard, -apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo"` ensures native Korean typographical balance.
- **Tabular Figures (`tnum`):** All numeric market readings (`원/kWh`, hourly volumes, megawatt indicators) must be rendered using tabular lining numbers (`font-variant-numeric: tabular-nums`) to prevent horizontal jittering across dynamic ticker refreshes.
- **Hierarchical Discipline:** Primary SMP prices and peak demand values leverage `metric-val` (`32px`, bold) paired directly with muted `label-md` unit tags (`#64748B`), establishing clear cognitive separation between data values and descriptive labels.

## Layout & Spacing

The dashboard employs a fluid 12-column grid system built to handle high-density analytics gracefully on desktop, consolidating seamlessly into modular card stacks on mobile devices.

- **Breakpoints:**
  - **Desktop (≥ 1280px):** 12 columns, `1.5rem` gutters, max canvas width `1440px` with `2rem` margins. Primary metrics span 3 or 4 columns; the hourly SMP bar chart spans 8 columns alongside a 4-column contextual AI analysis insight drawer.
  - **Tablet (768px – 1279px):** 6 columns, `1.25rem` gutters, `1.5rem` margins. Chart modules span full width, with auxiliary market overview metrics wrapping into 2-column or 3-column sub-grids.
  - **Mobile (< 768px):** Single-column stacked cards, `1rem` margins, `0.75rem` vertical separation between metric cards. Horizontal carousel or swipe gestures are permitted for rapid date-stepping and hourly bar scrubbing.
- **Internal Component Spacing:**
  - `space-xs` (4px): Chip internal spacing, badge icon gap.
  - `space-sm` (8px): Form input padding, label-to-value relationship gaps.
  - `space-md` (16px): Standard inner card padding for sub-metrics.
  - `space-lg` (24px): Primary data card internal padding, section breaks.
  - `space-xl` (32px): Dashboard zone separating dividers.

## Elevation & Depth

Visual hierarchy uses a refined combination of clean, single-pixel perimeter strokes and soft, ambient diffused shadows. Heavy drops and aggressive skeuomorphism are rejected in favor of high-clarity tonal surfacing.

- **Level 0 (Canvas Base):** Flat `#F8FAFC`, zero shadow.
- **Level 1 (Standard Card Container):** Surface `#FFFFFF` encased in a crisp border `1px solid #E2E8F0`, accompanied by a subtle ambient shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Active/Hover States & Dropdowns):** Used for date-picker dropdowns, time-range selectors, and hover states on interactive bar chart bars: `0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.03)` with border `#CBD5E1`.
- **Level 3 (AI Insight Callout Container):** Ambient warm-tinted halo effect using translucent primary ambient reflection: `0 8px 24px -4px rgba(249, 115, 22, 0.12)`, bordered by `rgba(249, 115, 22, 0.25)` over a pure white or warm pastel gradient foundation (`#FFFFFF` to `#FFF7ED`).

## Shapes

The design system maintains a modern, approachable geometry with friendly, rounded corners that counteract the rigidity of tabular data.

- **Standard Cards & Containers:** Configured with `rounded-xl` (`1rem` / 16px) or `rounded-2xl` (`1.5rem` / 24px) for major dashboard panels, ensuring large visual surfaces feel soft and approachable.
- **Interactive Controls (Inputs, Selectors, Date Pickers):** Standardized on `rounded-lg` (`0.5rem` / 8px) to reinforce functional precision.
- **Status Pills, Price Badges & Unit Tags:** Configured as full capsules (`9999px`) to immediately distinguish informational status from structural layout cards.
- **Chart Visual Elements:** Hourly bar chart bars feature soft top-corner radii (`4px` top-left, `4px` top-right; flat base) to avoid sharp vertical bars.

## Components

### Buttons & Interactive Controls
- **Primary Action Button:** Solid `#F97316` fill, `#FFFFFF` text, `0.5rem` radius, bold weight. Hover transitions to `#EA580C`. Active state adds subtle inner shadow.
- **Secondary / Filter Buttons:** Transparent background with `#FFFFFF` fill, bordered with `#E2E8F0`, slate text (`#0F172A`). Hover transitions to slate border `#CBD5E1` and `#F8FAFC` surface fill.
- **Date Picker Dropdown:** Segmented pill or bounded container displaying `YYYY.MM.DD (요일)`, chevron icon right-aligned, surface `#FFFFFF` with border `#E2E8F0`. On click, elevates to Level 2 with quick day-stepper controls (어제, 오늘, 1주일 전).

### Badges & Status Chips
- **SMP Price Trend Indicators:** Pill container with small upward/downward delta arrow. 
  - Upward spike: Background `#FFF7ED`, text `#EA580C`.
  - Downward/Stable: Background `#ECFDF5`, text `#059669`.
- **Market Status Badges:** Fixed at 11px font size, uppercase/Korean label (e.g., `실시간`, `확정치`), with a 6px circular dot indicator that pulses when showing live interval feeds.

### Data Visualization Containers (Hourly SMP Bar Chart)
- **Chart Shell:** Encapsulated inside a Level 1 card container with internal header (Title, Average Line Toggle, Peak Hour Highlight Tag).
- **Bars:** Default neutral slate bars (`#E2E8F0` or `#CBD5E1`). Highlighted or current-hour bars filled with vibrant `#F97316`. Average reference mark displayed as a dashed `#94A3B8` horizontal line.
- **Interactive Tooltip:** Level 2 elevation, `#0F172A` deep background with `#FFFFFF` tabular readout of exact `원/kWh` value and relative change vs. yesterday.

### AI Analysis Insight Container (오늘의 시장 분석)
- **Container Styling:** Bordered with subtle `rgba(249, 115, 22, 0.25)` and a gradient top accent line (`#F97316` to `#FBBF24`, height 3px). Surface tinted with ultra-soft `#FFFBF5`.
- **Content Structure:** Small radiant spark icon (✨), bold summary statement (e.g., "오늘 14시~16시 태양광 발전량 증가로 SMP가 전일 대비 12% 하락했습니다"), followed by 2 bulleted key takeaway tags for fast scanning.

### Institutional Footnotes & Attribution
- **Footnote Tags:** Subdued, low-contrast text block positioned at the bottom of data modules: `출처: KPX 전력거래소 (전력정보공개시스템 EPSIS 기준)`. Includes small institutional checkmark icon and timestamp of last data fetch (`갱신: 2025.02.24 14:05:12`).